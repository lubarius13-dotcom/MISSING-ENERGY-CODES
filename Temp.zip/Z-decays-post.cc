// Z-decay-post.cc — decay extra B’s and stamp daughters with decay vertex.
// Inputs (<exec>/Z-decay):
//   z-decay-products.txt
//   z-decay-products-B.txt
// Outputs (<exec>/Z-decay):
//   z-decay-products-merged.txt    (NO B hadrons inside)
//   B-data.txt                     (first B only, verbatim 9 fields)

#include "Pythia8/Pythia.h"

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <sys/types.h>
#include <omp.h>

using namespace Pythia8;

// ---------- small utils ----------
static std::string execDir(const char* argv0) {
  std::string s = (argv0 ? argv0 : "");
  auto pos = s.find_last_of('/');
  if (pos == std::string::npos) return ".";
  if (pos == 0) return "/";
  return s.substr(0, pos);
}
static bool dirExists(const std::string& path) {
  struct stat st{};
  return (stat(path.c_str(), &st) == 0) && S_ISDIR(st.st_mode);
}
static bool makeDirIfNeeded(const std::string& path) {
  if (dirExists(path)) return true;
  if (mkdir(path.c_str(), 0755) == 0) return true;
  if (errno == EEXIST) return true;
  return false;
}
static bool isBlank(const std::string& s) {
  for (char c : s) if (!std::isspace(static_cast<unsigned char>(c))) return false;
  return true;
}

// ---------- PDG helpers ----------
static inline bool isBHadronAbs(int a) {
  switch (a) { case 511: case 521: case 531: case 5122: return true; default: return false; }
}
static inline bool isBHadron(int id) { return isBHadronAbs(std::abs(id)); }

// ---------- 9-field record ----------
struct PRec {
  int id;
  double px, py, pz, e;
  double x, y, z, t;
};

static std::vector<PRec> parseLine9(const std::string& line) {
  std::vector<PRec> out;
  std::istringstream iss(line);
  while (true) {
    PRec p;
    if (!(iss >> p.id)) break;
    if (!(iss >> p.px >> p.py >> p.pz >> p.e)) break;
    if (!(iss >> p.x  >> p.y  >> p.z  >> p.t )) break;
    out.push_back(p);
  }
  return out;
}

static std::string toLine9(const std::vector<PRec>& parts) {
  std::ostringstream oss;
  oss.setf(std::ios::fmtflags(0), std::ios::floatfield);
  for (const auto& p : parts) {
    oss << p.id << ' '
        << p.px << ' ' << p.py << ' ' << p.pz << ' ' << p.e << ' '
        << p.x  << ' ' << p.y  << ' ' << p.z  << ' ' << p.t << ' ';
  }
  return oss.str();
}

// ---------- Pythia config (decays only) ----------
static void setUpDecayer(Pythia& py) {
  py.readString("Print:quiet = on");
  py.readString("ProcessLevel:all = off");
  py.readString("PartonLevel:all  = off");
  py.readString("HadronLevel:Hadronize = off");
  py.readString("HadronLevel:Decay = on");
  py.readString("ParticleDecays:limitTau0 = off");
  py.readString("Check:event = off");
  // Make sure B hadrons are allowed to decay
  py.particleData.mayDecay( 511, true); py.particleData.mayDecay(-511, true);
  py.particleData.mayDecay( 521, true); py.particleData.mayDecay(-521, true);
  py.particleData.mayDecay( 531, true); py.particleData.mayDecay(-531, true);
  py.particleData.mayDecay(5122, true); py.particleData.mayDecay(-5122, true);
  py.init();
}

// βγ cτ fallback in mm; time increment = γτ0 (mm/c)
static void fallbackDecayVertex(const PRec& b, double m, double tau0_mm,
                                double& x, double& y, double& z, double& t) {
  if (tau0_mm <= 0.0 || m <= 0.0) { x=b.x; y=b.y; z=b.z; t=b.t; return; }
  const double p = std::sqrt(b.px*b.px + b.py*b.py + b.pz*b.pz);
  if (p <= 0.0 || b.e <= 0.0) { x=b.x; y=b.y; z=b.z; t=b.t; return; }
  const double beta  = p / b.e;
  const double gamma = b.e / m;
  const double L  = beta * gamma * tau0_mm;
  const double dt = gamma * tau0_mm; // mm/c
  const double nx = b.px / p, ny = b.py / p, nz = b.pz / p;
  x = b.x + nx * L; y = b.y + ny * L; z = b.z + nz * L; t = b.t + dt;
}

// Decay a B hadron and return final daughters **with the B’s decay vertex**.
static std::vector<PRec> decayInjectedB(Pythia& py, const PRec& b) {
  Event& ev = py.event;
  ev.reset();

  const double p2 = b.px*b.px + b.py*b.py + b.pz*b.pz;
  double m2 = b.e*b.e - p2; if (m2 < 0) m2 = 0.0;
  const double m  = std::sqrt(m2);

  // Status = 2 (decaying resonance) so moreDecays() actually decays it.
  const int iB = ev.append(b.id, 2, 0, 0, b.px, b.py, b.pz, b.e, m);
  ev[iB].xProd(b.x); ev[iB].yProd(b.y); ev[iB].zProd(b.z); ev[iB].tProd(b.t);

  py.moreDecays();

  // Grab vertex from daughters; if nothing changed, fallback with βγ cτ.
  // Prefer the first found daughter’s production vertex as the decay point.
  double vx = b.x, vy = b.y, vz = b.z, vt = b.t;
  bool gotDecVtx = false;

  for (int i = 0; i < ev.size(); ++i) {
    const Particle& q = ev[i];
    if (!q.isFinal()) continue;
    if (isBHadron(q.id())) continue;
    if (!gotDecVtx) {
      vx = q.xProd(); vy = q.yProd(); vz = q.zProd(); vt = q.tProd();
      gotDecVtx = true;
    }
  }

  if (!gotDecVtx) {
    // Pythia produced no daughters (shouldn’t happen); return empty.
    return {};
  }

  // If Pythia left vertex essentially equal to the input production vertex, fallback.
  const bool unchanged = (vx == b.x && vy == b.y && vz == b.z && vt == b.t);
  if (unchanged) {
    const double tau0 = py.particleData.tau0(b.id); // mm/c
    fallbackDecayVertex(b, m, tau0, vx, vy, vz, vt);
  }

  // Now collect final daughters with that decay vertex.
  std::vector<PRec> daughters; daughters.reserve(32);
  for (int i = 0; i < ev.size(); ++i) {
    const Particle& q = ev[i];
    if (!q.isFinal()) continue;
    if (isBHadron(q.id())) continue; // belt-and-suspenders
    PRec d;
    d.id = q.id();
    d.px = q.px(); d.py = q.py(); d.pz = q.pz(); d.e = q.e();
    d.x = vx; d.y = vy; d.z = vz; d.t = vt;   // **decay vertex**
    daughters.push_back(d);
  }
  return daughters;
}

// ------------------------------- main -------------------------------
int main(int, char* argv[]) {
  const std::string base = execDir(argv[0]);
  const std::string dir  = base + "/Z-decay";
  if (!makeDirIfNeeded(dir)) {
    std::cerr << "[ERROR] Cannot access/create '" << dir << "'.\n"; return 1;
  }

  const std::string pathProd   = dir + "/z-decay-products.txt";
  const std::string pathB      = dir + "/z-decay-products-B.txt";
  const std::string pathMerged = dir + "/z-decay-products-merged.txt";
  const std::string pathBdata  = dir + "/B-data.txt";

  std::ifstream fProd(pathProd.c_str());
  std::ifstream fB(pathB.c_str());
  if (!fProd || !fB) {
    std::cerr << "[ERROR] Cannot open required inputs.\n"; return 1;
  }

  std::vector<std::string> linesProd, linesB;
  { std::string s; while (std::getline(fProd, s)) linesProd.push_back(s); }
  { std::string s; while (std::getline(fB,    s)) linesB.push_back(s);    }

  if (linesProd.size() != linesB.size()) {
    std::cerr << "[ERROR] Line count mismatch: products=" << linesProd.size()
              << " vs B=" << linesB.size() << "\n";
    return 1;
  }

  const size_t N = linesProd.size();
  std::vector<std::string> merged(N), keptB(N);

  std::atomic<size_t> next{0};
  const int nThreads = std::max(1, omp_get_max_threads());

  #pragma omp parallel num_threads(nThreads)
  {
    Pythia py; setUpDecayer(py);

    for (;;) {
      size_t i = next.fetch_add(1, std::memory_order_relaxed);
      if (i >= N) break;

      const std::string& prodRaw = linesProd[i];
      const std::string& bRaw    = linesB[i];

      if (isBlank(bRaw)) {
        merged[i] = prodRaw;       // leave as-is
        keptB[i].clear();          // no B stored
        continue;
      }

      std::vector<PRec> prod = parseLine9(prodRaw);
      std::vector<PRec> Bs   = parseLine9(bRaw);

      // Keep first B verbatim in B-data.txt (never put B in merged)
      if (!Bs.empty()) {
        const PRec& keep = Bs.front();
        std::ostringstream oss;
        oss << keep.id << ' ' << keep.px << ' ' << keep.py << ' ' << keep.pz << ' ' << keep.e << ' '
            << keep.x  << ' ' << keep.y  << ' ' << keep.z  << ' ' << keep.t;
        keptB[i] = oss.str();
      } else {
        keptB[i].clear();
      }

      // Start from products with ALL B hadrons stripped (handles early mixed files)
      std::vector<PRec> out; out.reserve(prod.size() + 16);
      for (const auto& p : prod) if (!isBHadron(p.id)) out.push_back(p);

      // Decay remaining Bs (skip the one we kept)
      for (size_t j = 1; j < Bs.size(); ++j) {
        const PRec& b = Bs[j];
        if (!isBHadron(b.id)) continue; // ignore garbage
        std::vector<PRec> dtrs = decayInjectedB(py, b);
        out.insert(out.end(), dtrs.begin(), dtrs.end());
      }

      // Final safety: no B hadrons in merged
      std::vector<PRec> finalOut; finalOut.reserve(out.size());
      for (const auto& q : out) if (!isBHadron(q.id)) finalOut.push_back(q);

      merged[i] = toLine9(finalOut);
    }
  }

  // Write outputs
  {
    std::ofstream fm(pathMerged.c_str());
    if (!fm) { std::cerr << "[ERROR] Cannot open '" << pathMerged << "'.\n"; return 1; }
    for (const auto& s : merged) fm << s << '\n';
  }
  {
    std::ofstream fb(pathBdata.c_str());
    if (!fb) { std::cerr << "[ERROR] Cannot open '" << pathBdata << "'.\n"; return 1; }
    for (const auto& s : keptB) fb << s << '\n';
  }

  std::cout << "[INFO] Wrote:\n  " << pathMerged << "\n  " << pathBdata << "\n";
  return 0;
}
