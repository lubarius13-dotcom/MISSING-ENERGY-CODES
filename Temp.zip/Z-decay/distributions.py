#!/usr/bin/env python3
# plot_energy_categories.py
#
# Reads:
#   - z-decay-products-merged.txt
#   - B-data.txt
# located in the SAME folder as this script (by default).
#
# For each event (line), it computes the total energy stored in:
#   * neutrinos:      (±12, ±14, ±16)
#   * neutral:        photons (22), KL (130), neutron (2112) and antineutron (-2112)
#   * e/μ:            electrons/positrons (±11), muons (±13)
#   * charged hadrons: pions (±211), kaons (±321), protons/antiprotons (±2212)
# and the energy of the kept B meson from B-data.txt (if present).
#
# Supports both 9-field per particle (id px py pz E x y z t)
# and legacy 5-field (id px py pz E).

import argparse
import os
import sys
import math

import numpy as np
import matplotlib.pyplot as plt


def parse_event_line(line):
    """
    Parse a space-separated line containing repeated particle blocks, where each block is either:
      - 9 fields: id px py pz E x y z t
      - 5 fields: id px py pz E  (legacy)
    Return list of (id, E) tuples.
    """
    line = line.strip()
    if not line:
        return []

    toks = line.split()
    n = len(toks)

    # Prefer clean divisibility by 9; else 5; else mixed fallback.
    out = []
    if n % 9 == 0:
        for i in range(0, n, 9):
            pid = int(toks[i + 0])
            e   = float(toks[i + 4])
            out.append((pid, e))
        return out
    if n % 5 == 0:
        for i in range(0, n, 5):
            pid = int(toks[i + 0])
            e   = float(toks[i + 4])
            out.append((pid, e))
        return out

    # Fallback: try to consume as many 9-field blocks as possible, then 5-field.
    i = 0
    while i + 9 <= n:
        pid = int(toks[i + 0]); e = float(toks[i + 4])
        out.append((pid, e))
        i += 9
    while i + 5 <= n:
        pid = int(toks[i + 0]); e = float(toks[i + 4])
        out.append((pid, e))
        i += 5
    return out


def main():
    parser = argparse.ArgumentParser(description="Per-event energy category histograms.")
    parser.add_argument("--merged", default="z-decay-products-merged.txt",
                        help="Path to z-decay-products-merged (default: z-decay-products-merged.txt)")
    parser.add_argument("--bdata", default="B-data.txt",
                        help="Path to B-data.txt (default: B-data.txt)")
    parser.add_argument("--out", default="energy_categories.png",
                        help="Output plot filename (default: energy_categories.png)")
    parser.add_argument("--bins", type=int, default=60, help="Number of histogram bins")
    args = parser.parse_args()

    if not os.path.isfile(args.merged):
        print(f"[ERROR] Cannot find '{args.merged}'. Put this script in the same folder as your data files.", file=sys.stderr)
        sys.exit(1)
    if not os.path.isfile(args.bdata):
        print(f"[ERROR] Cannot find '{args.bdata}'. Put this script in the same folder as your data files.", file=sys.stderr)
        sys.exit(1)

    # PDG categories
    neutrinos = { 12, -12, 14, -14, 16, -16 }
    neutral_special = { 22, 130, 2112, -2112 }
    electrons_muons = { 11, -11, 13, -13 }
    charged_hadrons = { 211, -211, 321, -321, 2212, -2212 }

    # Accumulators (per event)
    e_nu, e_neu, e_emu, e_ch, e_b = [], [], [], [], []

    with open(args.merged, "r") as fm, open(args.bdata, "r") as fb:
        i = 0
        while True:
            lM = fm.readline()
            lB = fb.readline()
            if not lM and not lB:
                break
            if not lM or not lB:
                print(f"[WARN] Line count mismatch at event {i}. Stopping at shortest file.", file=sys.stderr)
                break

            parts = parse_event_line(lM)

            s_nu = s_ne = s_em = s_ch = 0.0
            for pid, e in parts:
                if pid in neutrinos:
                    s_nu += e
                elif pid in neutral_special:
                    s_ne += e
                elif pid in electrons_muons:
                    s_em += e
                elif pid in charged_hadrons:
                    s_ch += e

            e_nu.append(s_nu)
            e_neu.append(s_ne)
            e_emu.append(s_em)
            e_ch.append(s_ch)

            # Kept B (from B-data.txt): if multiple, take the first.
            bparts = parse_event_line(lB.strip())
            if bparts:
                e_b.append(bparts[0][1])

            i += 1

    # Prepare histograms
    arrays = [np.array(e_nu), np.array(e_neu), np.array(e_emu), np.array(e_ch)]
    eb_array = np.array(e_b) if len(e_b) > 0 else None

    max_vals = [a.max() for a in arrays if a.size > 0]
    if eb_array is not None and eb_array.size > 0:
        max_vals.append(eb_array.max())
    if not max_vals:
        print("[ERROR] No energies parsed; nothing to plot.", file=sys.stderr)
        sys.exit(1)

    emax = max(max_vals)
    if not np.isfinite(emax) or emax <= 0:
        emax = 1.0

    # Plot
    fig, ax = plt.subplots(figsize=(9, 6))

    def plot_if_nonempty(data, label):
        arr = np.array(data)
        if arr.size > 0 and np.max(arr) > 0:
            ax.hist(arr, bins=args.bins, range=(0, emax), histtype="step", label=label, linewidth=1.2)
            return 1
        return 0

    plotted = 0
    plotted += plot_if_nonempty(e_nu,  "neutrinos")
    plotted += plot_if_nonempty(e_neu, "neutral (γ, K_L, n)")
    plotted += plot_if_nonempty(e_emu, "e/μ")
    plotted += plot_if_nonempty(e_ch,  "π±/K±/p(±)")
    if eb_array is not None:
        plotted += plot_if_nonempty(e_b, "kept B")

    if plotted == 0:
        print("[ERROR] All categories are empty (or zero energy). Nothing to plot.", file=sys.stderr)
        sys.exit(1)

    ax.set_xlabel("E [GeV]")
    ax.set_ylabel("nentries")
    ax.set_title("Per-event energy by category")
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(args.out, dpi=150)
    print(f"[INFO] Saved plot to {args.out}")
    print(f"[INFO] Events parsed: {len(e_nu)}")
    print(f"[INFO] Kept B entries: {len(e_b)}")


if __name__ == "__main__":
    main()

