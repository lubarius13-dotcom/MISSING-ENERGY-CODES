// Z-decay-check.cc
//
// Momentum conservation check for the produced files.
// Run it from inside the directory that contains:
//   - z-decay-products-merged.txt
//   - B-data.txt
//
// Build:
//   g++ -O2 -std=c++17 Z-decay-check.cc -o zcheck
//
// Run:
//   ./zcheck
// ---------------------------------------------------------------------------

#include <cmath>
#include <cstddef>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cctype>
#include <iomanip>

// Defaults for Z at rest:
static constexpr double E_CM = 91.1876;   // GeV
static constexpr double P_TOL = 1e-3;     // GeV per component
static constexpr double E_TOL = 5e-3;     // GeV

// Print diagnostics for the first K failing events
static constexpr int SHOW_FIRST_FAILS = 8;

struct P { int id; double px, py, pz, e; };

static std::vector<std::string> tokenize(const std::string& line) {
  std::istringstream iss(line);
  std::vector<std::string> t; std::string w;
  while (iss >> w) t.push_back(w);
  return t;
}

static std::vector<P> parseTokens(const std::vector<std::string>& tok, int& nBlocks, std::string& fmt) {
  std::vector<P> out;
  nBlocks = 0; fmt.clear();
  const size_t n = tok.size();
  if (!n) return out;

  auto parse5 = [&](size_t i) -> P {
    return P{ std::stoi(tok[i+0]), std::stod(tok[i+1]), std::stod(tok[i+2]),
              std::stod(tok[i+3]), std::stod(tok[i+4]) };
  };
  auto parse9 = [&](size_t i) -> P {
    // same as parse5, skip vertex columns
    return parse5(i);
  };

  if (n % 9 == 0) {
    fmt = "9";
    nBlocks = int(n / 9);
    out.reserve(nBlocks);
    for (size_t i = 0; i < n; i += 9) out.push_back(parse9(i));
    return out;
  }
  if (n % 5 == 0) {
    fmt = "5";
    nBlocks = int(n / 5);
    out.reserve(nBlocks);
    for (size_t i = 0; i < n; i += 5) out.push_back(parse5(i));
    return out;
  }

  // Mixed/trailing tokens — try to consume 9-field blocks first then 5-field
  fmt = "mixed";
  size_t i = 0;
  while (i + 9 <= n) { out.push_back(parse9(i)); i += 9; ++nBlocks; }
  while (i + 5 <= n) { out.push_back(parse5(i)); i += 5; ++nBlocks; }
  return out;
}

static std::vector<P> parseLine(const std::string& line, int& nBlocks, std::string& fmt, int& nTok) {
  auto tok = tokenize(line);
  nTok = int(tok.size());
  return parseTokens(tok, nBlocks, fmt);
}

static bool isBlank(const std::string& s) {
  for (char c : s) if (!std::isspace(static_cast<unsigned char>(c))) return false;
  return true;
}

int main() {
  const std::string fMerged = "z-decay-products-merged.txt";
  const std::string fBdata  = "B-data.txt";

  std::ifstream fm(fMerged.c_str());
  std::ifstream fb(fBdata.c_str());
  if (!fm || !fb) {
    std::cerr << "[ERROR] Cannot open '" << fMerged << "' or '" << fBdata << "'.\n";
    return 1;
  }

  std::vector<std::string> lm, lb;
  { std::string s; while (std::getline(fm, s)) lm.push_back(s); }
  { std::string s; while (std::getline(fb, s)) lb.push_back(s); }
  if (lm.size() != lb.size()) {
    std::cerr << "[ERROR] Line count mismatch: merged=" << lm.size()
              << " B-data=" << lb.size() << "\n";
    return 1;
  }

  const size_t N = lm.size();
  size_t nFailP = 0, nFailE = 0, printed = 0;

  for (size_t i=0; i<N; ++i) {
    const std::string& lM = lm[i];
    const std::string& lB = lb[i];

    int nTokM=0, nTokB=0, nBlkM=0, nBlkB=0;
    std::string fmtM, fmtB;

    std::vector<P> partsM = parseLine(lM, nBlkM, fmtM, nTokM);
    std::vector<P> partsB;
    if (!isBlank(lB)) partsB = parseLine(lB, nBlkB, fmtB, nTokB);

    // Sum contributions separately (so we can print each)
    auto sum4 = [](const std::vector<P>& v){
      double sx=0, sy=0, sz=0, se=0;
      for (const auto& p : v) { sx+=p.px; sy+=p.py; sz+=p.pz; se+=p.e; }
      return std::array<double,4>{sx,sy,sz,se};
    };

    auto sM = sum4(partsM);
    auto sB = sum4(partsB);

    // TOTAL = merged + kept B(s)
    const double sx = sM[0] + sB[0];
    const double sy = sM[1] + sB[1];
    const double sz = sM[2] + sB[2];
    const double se = sM[3] + sB[3];

    bool badP = (std::abs(sx) > P_TOL) || (std::abs(sy) > P_TOL) || (std::abs(sz) > P_TOL);
    bool badE = (std::abs(se - E_CM) > E_TOL);

    if (badP) ++nFailP;
    if (badE) ++nFailE;

    if ((badP || badE) && printed < SHOW_FIRST_FAILS) {
      std::cout << std::fixed << std::setprecision(6);
      std::cout << "[WARN] Event " << i << "\n"
                << "  merged:  blocks=" << nBlkM << " fmt=" << fmtM
                << " tokens=" << nTokM
                << "  sum(p)=(" << sM[0] << "," << sM[1] << "," << sM[2] << ")  E=" << sM[3] << "\n";
      if (!isBlank(lB)) {
        std::cout << "  B-data:  blocks=" << nBlkB << " fmt=" << fmtB
                  << " tokens=" << nTokB
                  << "  sum(p)=(" << sB[0] << "," << sB[1] << "," << sB[2] << ")  E=" << sB[3] << "\n";
      } else {
        std::cout << "  B-data:  <empty line>\n";
      }
      std::cout << "  TOTAL:   sum(p)=(" << sx << "," << sy << "," << sz << ")"
                << "  sum(E)=" << se << " (target " << E_CM << ")\n";
      ++printed;
    }

    // also warn if the B-data line had tokens but parsed to zero blocks (format problem)
    if (!isBlank(lB) && nTokB > 0 && nBlkB == 0 && printed < SHOW_FIRST_FAILS) {
      std::cout << "  [HINT] B-data line had " << nTokB
                << " tokens but 0 blocks parsed. Mixed/garbled format?\n";
      ++printed;
    }
  }

  std::cout << "[CHECK] Events: " << N << "\n"
            << "        momentum fails: " << nFailP << " (|px,py,pz| < " << P_TOL << " GeV)\n"
            << "        energy   fails: " << nFailE << " (|E - " << E_CM << "| < " << E_TOL << " GeV)\n";

  if (nFailP == 0 && nFailE == 0) {
    std::cout << "[OK] All events within tolerances.\n";
  } else {
    std::cout << "[NOTE] Above, I printed merged vs B-data contributions for the first "
              << SHOW_FIRST_FAILS << " failing events so you can see exactly what's missing.\n";
  }
  return 0;
}

