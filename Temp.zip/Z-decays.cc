// Z-decays.cc
//
// On-shell Z at e+e- collider (sqrt(s)=mZ). Parallel event loop.
// Always writes two aligned files per event:
//   Z-decay/z-decay-products.txt      : final-state particles (if Bstable=true, excludes B mesons)
//   Z-decay/z-decay-products-B.txt    : if Bstable=true -> B mesons
//      (per particle: id px py pz E xProd yProd zProd tProd)
//      (units: x,y,z in mm; t in mm/c)
//
// Usage:
//   ./myprog -n <NEVT> -ifbbar true  -ifBstable <true|false>
//   ./myprog -n <NEVT> -ifbbar false
//
// Build example:
//   g++ -O2 -std=c++17 -fopenmp Z-decays.cc -o myprog \
//       -I/home/name/Downloads/pythia-mixing-dev/include \
//       -L/home/name/Downloads/pythia-mixing-dev/lib \
//       -Wl,-rpath,/home/name/Downloads/pythia-mixing-dev/lib \
//       -lpythia8 -ldl
// ------------------------------------------------------------------------------------------------

#include "Pythia8/Pythia.h"
#include "Pythia8/PythiaParallel.h"

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <sys/types.h>

using namespace Pythia8;

// ------------------ small utils (no <filesystem>) ------------------
static std::string execDir(const char* argv0) {
  std::string s = (argv0 ? argv0 : "");
  auto pos = s.find_last_of('/');
  if (pos == std::string::npos) return ".";
  if (pos == 0) return "/";
  return s.substr(0, pos);
}
static bool dirExists(const std::string& path) {
  struct stat st{};
  return (stat(path.c_str(), &st) == 0) && S_ISDIR(st.st_mode);
}
static bool makeDirIfNeeded(const std::string& path) {
  if (dirExists(path)) return true;
  if (mkdir(path.c_str(), 0755) == 0) return true;
  if (errno == EEXIST) return true;
  return false;
}
static bool ieq(const std::string& a, const char* b) {
  if (a.size() != std::strlen(b)) return false;
  for (size_t i=0;i<a.size();++i) if (std::tolower(a[i]) != std::tolower(b[i])) return false;
  return true;
}

// --------------------- B-meson helpers ---------------------------------------
static inline bool isBmeson(int id) {
  switch (std::abs(id)) {
    case 511: case 521: return true; // B0, B+
    default: return false;
  }
}
static void freezeBmesons(Pythia& p) {
  auto frz = [&](int pdg){
    p.particleData.mayDecay( pdg, false);
    p.particleData.mayDecay(-pdg, false);
  };
  frz(511); frz(521);
}

// ----------------------- beam & process setup --------------------------------
static void setUpZpole(PythiaParallel& pp, bool onlyBB) {
  pp.readString("Beams:frameType = 1");
  pp.readString("Beams:idA = -11");
  pp.readString("Beams:idB = 11");
  pp.readString("Beams:eCM = 91.1876");
  pp.readString("WeakSingleBoson:ffbar2gmZ = on");

  if (onlyBB) {
    pp.readString("23:onMode = off");
    pp.readString("23:onIfMatch = 5 -5");
  }

  pp.readString("Next:numberShowInfo = 0");
  pp.readString("Next:numberShowProcess = 0");
  pp.readString("Next:numberShowEvent = 0");
}

// ------------------------------ usage ---------------------------------------
static void usage(const char* prog) {
  std::cerr
    << "Usage:\n"
    << "  " << prog << " -n <NEVT> -ifbbar true  -ifBstable <true|false>\n"
    << "  " << prog << " -n <NEVT> -ifbbar false\n\n"
    << "Notes:\n"
    << "  * Always writes two aligned files under <exec>/Z-decay/ :\n"
    << "      z-decay-products.txt      (final-state; per particle: id px py pz E xProd yProd zProd tProd)\n"
    << "      z-decay-products-B.txt    (B mesons if frozen; per particle: id px py pz E xProd yProd zProd tProd)\n";
}

// ---------------------------------- main -------------------------------------
int main(int argc, char* argv[]) {
  // ---- parse CLI ----
  long long nEvents = -1;
  bool ifbbar = false;
  bool ifBstable = false;
  bool ifBstable_set = false;

  for (int i=1; i<argc; ++i) {
    std::string a = argv[i];
    if (a == "-n" && i+1 < argc) {
      nEvents = std::stoll(argv[++i]);
    } else if (a == "-ifbbar" && i+1 < argc) {
      std::string v = argv[++i];
      ifbbar = ieq(v, "true");
    } else if (a == "-ifBstable" && i+1 < argc) {
      std::string v = argv[++i];
      ifBstable = ieq(v, "true");
      ifBstable_set = true;
    } else {
      usage(argv[0]);
      return 1;
    }
  }

  if (nEvents <= 0) { usage(argv[0]); return 1; }
  if (!ifbbar && ifBstable_set) {
    std::cerr << "[ERROR] -ifBstable may only be provided with -ifbbar true.\n";
    usage(argv[0]);
    return 1;
  }
  if (!ifbbar) ifBstable = false; // per spec: all modes => B mesons unstable

  // ---- prepare output dir & files ----
  const std::string base = execDir(argv[0]);
  const std::string outDir = base + "/Z-decay";
  if (!makeDirIfNeeded(outDir)) {
    std::cerr << "[ERROR] Cannot create/access '" << outDir << "'.\n";
    return 1;
  }
  const std::string pathMain = outDir + "/z-decay-products.txt";
  const std::string pathB    = outDir + "/z-decay-products-B.txt";

  std::ofstream fMain(pathMain.c_str());
  std::ofstream fB(pathB.c_str());
  if (!fMain || !fB) {
    std::cerr << "[ERROR] Cannot open output files.\n";
    return 1;
  }

  // ---- PythiaParallel set-up ----
  PythiaParallel pp;
  setUpZpole(pp, ifbbar);
  if (!pp.init()) {
    std::cerr << "[ERROR] PythiaParallel init failed.\n";
    return 1;
  }

  std::atomic<long long> done{0};
  std::atomic<long long> failed{0};
  std::mutex outMutex;

  // ---- parallel event loop ----
  pp.run((int)nEvents, [&](Pythia* p) {
    // Per-thread one-time B-freezing (only if requested)
    if (ifBstable) {
      static thread_local bool configured = false;
      if (!configured) {
        freezeBmesons(*p);
        configured = true;
      }
    }

    if (!p->next()) {
      failed++;
      // keep line alignment: write placeholder empty lines
      std::lock_guard<std::mutex> lock(outMutex);
      fMain << '\n';
      fB    << '\n';
      return;
    }

    std::ostringstream lineMain, lineB;
    const Event& ev = p->event;

    for (int i = 0; i < ev.size(); ++i) {
      const Particle& q = ev[i];
      if (!q.isFinal()) continue;

      const Vec4 vp = q.vProd(); // production vertex (mm, mm, mm, mm/c) via px,py,pz,e

      if (ifBstable && isBmeson(q.id())) {
        // Write B with 9 fields
        lineB
          << q.id() << ' ' << q.px() << ' ' << q.py() << ' ' << q.pz() << ' ' << q.e() << ' '
          << vp.px() << ' ' << vp.py() << ' ' << vp.pz() << ' ' << vp.e() << ' ';
      } else {
        // Write non-B final with 9 fields
        lineMain
          << q.id() << ' ' << q.px() << ' ' << q.py() << ' ' << q.pz() << ' ' << q.e() << ' '
          << vp.px() << ' ' << vp.py() << ' ' << vp.pz() << ' ' << vp.e() << ' ';
      }
    }

    {
      std::lock_guard<std::mutex> lock(outMutex);
      fMain << lineMain.str() << '\n';
      fB    << lineB.str()    << '\n';
    }

    long long d = ++done;
    if ((d % 10000) == 0) {
      std::lock_guard<std::mutex> lock(outMutex);
      std::cout << "[INFO] " << d << "/" << nEvents << " events\n";
    }
  });

  std::cout << "[INFO] Completed " << done << " events";
  if (failed) std::cout << " (" << failed << " failed)";
  std::cout << ".\n";
  std::cout << "[INFO] Wrote:\n  " << pathMain << "\n  " << pathB << "\n";

  pp.stat();
  return 0;
}

